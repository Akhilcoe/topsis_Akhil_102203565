from .topsis import topsis  # Import topsis from topsis.py
